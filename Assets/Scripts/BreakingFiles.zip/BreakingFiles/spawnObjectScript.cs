using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.MagicLeap;



// This class is responsible for spawning objects and targets in the scene, and moving the selected object based on the user's hand gestures.
public class SpawnObjectOnTrigger : MonoBehaviour
{
    // Class to store object path data consisting of position and timestamp
    [System.Serializable]
    public class ObjectPathData
    {
        public Vector3 position;
        public float timestamp;

        public ObjectPathData(Vector3 position, float timestamp)
        {
            this.position = position;
            this.timestamp = timestamp;
        }
    }

    private List<ObjectPathData> objectPath = new List<ObjectPathData>();
    private string fileName;

    //End of Serialized variables 


    private Vector3 nestSize = new Vector3(0.5f, 0.5f, 0.5f);
    private LevelType currentLevelType = LevelType.Basic;

    private Vector3 targetPosition;
    private GameObject selectedObject;


    // Variables related to object spawning and interaction

    private int reverseRotationCounter = 0;

    private Vector3 initialControllerOffset;

    private Transform previousControllerTransform;
    private float initialObjectDistance;

    private float spawnDistance = 1.0f; // 20 cm in front of the user's main camera

    //Gamification variables
    private int currentLevel = 1;
    private int levelCounter = 0;
    private int score = 0;
    private float levelStartTime;

    [SerializeField] private float smoothness = 5.0f;

    private bool isTriggerPressed = false;

    private float reachDistance = 5f; // The maximum interaction distance. You can adjust this to your needs.


    [SerializeField] private GameObject breadcrumbPrefab;


    void Start()
    {


        levelStartTime = Time.time;

        MLSegmentedDimmer.Activate();

        fileName = $"path_data_{levelCounter}-{currentLevel}.txt";



    }


    void Update()
    {
        if (selectedObject == null || resetStarted)
        {
            //Check to make sure we are not prevented from updating
            return;
        }

       // MoveObject();
        CheckObjectTargetInteraction();

      //  StorePreviousControllerTransform(); //Used to track controller transform

    }


    private void CheckObjectTargetInteraction()
    {
        if (selectedObject != null)
        {
            float interactionDistance = 0.1f; // The distance to interact with the target
            foreach (GameObject target in spawnedTargets)
            {
                if (Vector3.Distance(selectedObject.transform.position, target.transform.position) <= interactionDistance)
                {
                    // If it's color match level check if the tags match
                    if (currentLevelType == LevelType.ColorMatch && selectedObject.tag != target.tag)
                    {
                        // Failed condition, handle it here
                    }
                    else
                    {
                        LevelCompleted();
                        break;
                    }
                }
            }
        }
    }


    private void LevelCompleted() //LevelCompleted
    {
        // Print the object path
        PrintObjectPath();

        UpdateScore();
        levelStartTime = Time.time;

        UpdateLevel();

        ShowSuccessFeedback(spawnedTargets[0]); //Real target is always the first in the index

        resetStarted = true;
        Invoke("ResetScene", 2f);
    }

    private void ShowSuccessFeedback(GameObject targetObject) //attaches success particles to gameobject
    {
        // Attach the particle system to the target
        if (successParticle != null)
        {
            ParticleSystem particles = targetObject.AddComponent<ParticleSystem>();
            particles.Stop(); // Stop the particle system by default

            var mainModule = particles.main;
            mainModule.duration = 2f;
            particles.GetComponent<Renderer>().material = successParticle.GetComponent<Renderer>().material; // Copy the material from the successParticle
            float sizeMultiplier = 0.2f; // Change this value to adjust the size
            mainModule.startSizeMultiplier = successParticle.GetComponent<ParticleSystem>().main.startSizeMultiplier * sizeMultiplier;

            particles.Play();
        }

        if (successSound != null)
        {
            AudioSource audioSource = targetObject.AddComponent<AudioSource>(); // Add an AudioSource component to the target
            audioSource.clip = successSound;
            audioSource.playOnAwake = false;
            audioSource.spatialBlend = 1f; // Set the AudioSource to 3D sound
            audioSource.Play(); // Play the success sound
        }
    }


    private void UpdateLevel()
    { 
        levelCounter++;
        // If the counter reaches 15, move to the next level and reset the counter
        if (levelCounter >= 10)
        {
            currentLevel++;
            levelCounter = 0;
        }

        switch (currentLevel)
        {
            case 1:
                currentLevelType = LevelType.Basic;
                break;
            case 2:
                currentLevelType = LevelType.Inverted;
                break;
            case 3:
                currentLevelType = LevelType.ColorMatch;
                break;
            case 4:
                currentLevelType = LevelType.ColorMatchReverse;
                break;
            case 5:
                currentLevelType = LevelType.RandomEagle;
                break;
            case 6:
                currentLevelType = LevelType.Basic;
                break;
        }


}


    private void ResetScene() //Resets everything
    {
        // Reset the object and pad
        Destroy(spawnedObject);
        Destroy(spawnedPadObject);

        // Reset the selected object if it exists
        if (selectedObject != null)
            Destroy(selectedObject);

        // Iterate through the spawnedTargets list and destroy each GameObject
        foreach (GameObject target in spawnedTargets)
        {
            Destroy(target);
        }

        // Clear the spawnedTargets list
        spawnedTargets.Clear();

        // Spawn new object and target
        SpawnObjectAndTarget();

        // Clear the object path data
        ClearObjectPath();

        previousControllerTransform = null;

       // lastControllerPosition = Vector3.zero;

        resetStarted = false;
    }


}


