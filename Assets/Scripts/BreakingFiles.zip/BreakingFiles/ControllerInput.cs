using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.MagicLeap;
using System.Collections.Generic;


/* Intention is to call all gameManager functions from here
 * So ideally on event changes call GameManager.triggerDown or triggerUp
 * 
 */


public class NewBehaviourScript : MonoBehaviour
{

    public GameManager gameManager;
    [SerializeField] private ActionBasedController controller;
    private Camera mainCamera;
    private MagicLeapInputs mlInputs;
    private MagicLeapInputs.ControllerActions controllerActions;
    private XRRayInteractor xRRayInteractor;
    private UnityEngine.XR.XRInputSubsystem inputSubsystem;
    private bool isTriggerPressed = false;
        private Vector3 lastControllerPosition;


    // Start is called before the first frame update
    void Start()
    {
        mainCamera = Camera.main;
        mlInputs = new MagicLeapInputs();
        mlInputs.Enable();
        controllerActions = new MagicLeapInputs.ControllerActions(mlInputs);

        controllerActions.Trigger.performed += OnTriggerDown;
        controllerActions.Trigger.canceled += OnTriggerUp;
        controllerActions.Menu.performed += Menu_Performed;
        controllerActions.Bumper.performed += HandleOnBumper;
        controllerActions.TouchpadTouch.performed += TouchpadTouch_performed;


        MLSegmentedDimmer.Activate();
    }


    private void TouchpadTouch_performed(InputAction.CallbackContext obj)
    {
        Debug.LogError("TouchpadTouch_performed");
        LevelCompleted();
    }
    private void Menu_Performed(UnityEngine.InputSystem.InputAction.CallbackContext callbackContext)
    {
        Debug.LogError("Menu_Performed");


    }
    private void OnTriggerDown(UnityEngine.InputSystem.InputAction.CallbackContext callbackContext)
    {
        Debug.LogError("OnTriggerDown");
        isTriggerPressed = true;
        if (!resetStarted)
        {
            RaycastSelectObject();
        }

    }

    private void OnTriggerUp(UnityEngine.InputSystem.InputAction.CallbackContext callbackContext)
    {
        Debug.LogError("OnTriggerUp");
        isTriggerPressed = false;
        UnselectObject();

    }
    private void HandleOnBumper(UnityEngine.InputSystem.InputAction.CallbackContext callbackContext)
    {
        Debug.LogError("HandleOnBumper");
        if (!resetStarted)
            SpawnObjectAndTarget();
    }


    // Update is called once per frame
    void Update()
    {
        
    }

    private void UpdateTargetPosition()
    {
        RaycastHit hit;
        if (Physics.Raycast(controller.transform.position, controller.transform.forward, out hit, reachDistance))
        {
            Vector3 directionToHitPoint = (hit.point - controller.transform.position).normalized;
            // Maintain the bird at a certain distance (for example, the initial distance) from the controller
            targetPosition = controller.transform.position + directionToHitPoint * initialObjectDistance;
        }
        else
        {
            targetPosition = controller.transform.position + controller.transform.forward * initialObjectDistance;
        }
    }



    private void UnselectObject()
    {
        Debug.LogError("UnselectObject");
        previousControllerTransform = null;
        lastControllerPosition = Vector3.zero;
        selectedObject = null;
    }

    private void MoveObject()
    {
        if (selectedObject != null)
        {
            if (isTriggerPressed)
            {
                // Update target position
                UpdateTargetPosition();

                // If reverse is on
                if (reverseRotation)
                {
                    MoveInReverse();
                }
                // If reverse is off
                else
                {
                    MoveNormally();
                }
            }
            else // If the trigger is not pressed
            {
                // Reset last controller position
                lastControllerPosition = Vector3.zero;
            }

            // Log the new object path data
            objectPath.Add(new ObjectPathData(selectedObject.transform.position, Time.time));
        }
    }

    private void MoveNormally()
    {
        // Smoothly move the bird towards the target position
        selectedObject.transform.position = targetPosition;

        // Rotate the bird to align with the controller's forward direction
        Vector3 controllerForward = -controller.transform.forward; // Added a negative so the bird ends up facing the user
        controllerForward.y = 0f; // Ignore vertical component to ensure the bird stays upright
        Quaternion targetRotation = Quaternion.LookRotation(controllerForward, Vector3.up);
        selectedObject.transform.rotation = targetRotation;
    }

    private void MoveInReverse()
    {
        // If it's the first frame the trigger is pressed, store the controller's position and exit the function early
        if (lastControllerPosition == Vector3.zero)
        {
            lastControllerPosition = targetPosition;
            return;
        }

        // Calculate the change in controller's position
        Vector3 controllerMovement = targetPosition - lastControllerPosition;

        // Update the last controller position
        lastControllerPosition = targetPosition;

        // Move the bird in the opposite direction of the controller's movement
        selectedObject.transform.position -= controllerMovement;

        // Rotate the bird to align with the opposite of the controller's forward direction
        Vector3 controllerBackward = -controller.transform.forward;
        controllerBackward.y = 0f; // Ignore vertical component to ensure the bird stays upright
        Quaternion targetRotation = Quaternion.LookRotation(controllerBackward, Vector3.up);
        selectedObject.transform.rotation = Quaternion.Lerp(selectedObject.transform.rotation, targetRotation, smoothness * Time.deltaTime);
    }

    private void RaycastSelectObject()
    {
        RaycastHit hit;

        // Cast a ray from the controller's current position in the direction it's facing
        if (Physics.Raycast(controller.transform.position, controller.transform.forward, out hit))
        {
            // Check if the hit object is of interest based on its tag
            if (IsTagInArray(hit.collider.gameObject.tag, birdTags))
            {
                selectedObject = hit.collider.gameObject;
                initialObjectDistance = Vector3.Distance(selectedObject.transform.position, controller.transform.position);

                // Set the target position to the hit position
                targetPosition = hit.point;
            }
        }
        else
        {
            selectedObject = null;
        }
    }


    private void StorePreviousControllerTransform()
    {
        if (previousControllerTransform == null)
        {
            previousControllerTransform = new GameObject("PreviousControllerTransform").transform;
        }

        previousControllerTransform.position = controller.transform.position;
        previousControllerTransform.rotation = controller.transform.rotation;
    }

    private bool IsTagInArray(string tag, string[] tagArray)
    {
        foreach (string t in tagArray)
        {
            if (tag.Equals(t))
            {
                return true;
            }
        }
        return false;
    }
}


//TODO: In loving memory of Spot and Henrieta

public class Level : MonoBehaviour
{

    public enum LevelType { Basic, Inverted, ColorMatch, ColorMatchReverse, RandomEagle };

    // Add all the properties that you want the level to have:
    public GameObject[] objectPrefabs;
    public GameObject[] targetPrefabs;
    public GameObject fillerTargetPrefab;
    public GameObject eaglePrefab;
    public GameObject objectPadPrefab;
    public GameObject successParticle;
    public AudioClip successSound;
    public bool reverseRotation = false;
    public LevelType currentLevelType = LevelType.Basic;
    public string[] birdTags;
    public string levelTag;
    public Vector3 nestSize = new Vector3(0.5f, 0.5f, 0.5f);
    private GameObject breadcrumbPrefab;

    private Direction[] availableDirections = { Direction.Right, Direction.Left, Direction.Up, Direction.Down };
    private Direction targetDirection = Direction.Left;
    private bool initialSpawnLocationSet = false;
    private Vector3 initialSpawnLocation;
    private bool resetStarted = false;

    private GameObject target;
    private List<GameObject> spawnedTargets = new List<GameObject>(); // List to hold spawned targets


    private GameObject spawnedObject;
    private GameObject spawnedPadObject;

    public Level(GameObject[] objectPrefabs, GameObject[] targetPrefabs, GameObject fillerTargetPrefab, GameObject eaglePrefab,
                 GameObject objectPadPrefab, GameObject successParticle, AudioClip successSound, bool reverseRotation,
                 LevelType currentLevelType, string[] birdTags, string levelTag, Vector3 nestSize, Vector3 initialSpawnLocation, GameObject breadcrumbPrefab)
    {
        this.objectPrefabs = objectPrefabs;
        this.targetPrefabs = targetPrefabs;
        this.fillerTargetPrefab = fillerTargetPrefab;
        this.eaglePrefab = eaglePrefab;
        this.objectPadPrefab = objectPadPrefab;
        this.successParticle = successParticle;
        this.successSound = successSound;
        this.reverseRotation = reverseRotation;
        this.currentLevelType = currentLevelType;
        this.birdTags = birdTags;
        this.levelTag = levelTag;
        this.nestSize = nestSize;
        this.initialSpawnLocation = initialSpawnLocation;
        this.breadcrumbPrefab = breadcrumbPrefab;
    }

    public void SpawnObjectAndTarget()
    {



        if (objectPrefabs == null || objectPrefabs.Length == 0 || targetPrefabs == null || targetPrefabs.Length == 0)
        {
            Debug.LogError("Object prefab or target prefab is not assigned.");
            return;
        }

        //The intention here is to check what kind of level we are on, and instantiate based on that
        int randomIndex = Random.Range(0, objectPrefabs.Length); //We make a random index to know which target and object we are pursuing
        levelTag = birdTags[randomIndex]; //Why? so that then we can easily compare what we intend to check for?

        int directionIndex = Random.Range(0, availableDirections.Length);
        targetDirection = GenerateRandomDirection();

        // Check if the initial spawn location is set, if not, set it
        if (!initialSpawnLocationSet)
        {
            initialSpawnLocation = mainCamera.gameObject.transform.position + (mainCamera.gameObject.transform.forward * spawnDistance) - new Vector3(0, 0.1f, 0);
            //            initialSpawnLocation = mainCamera.gameObject.transform.position + (mainCamera.gameObject.transform.forward * spawnDistance);
            initialSpawnLocationSet = true;
        }

        float randomDistance = Random.Range(-0.05f, 0.05f);

        //Creating the level based on conditions

        switch (currentLevelType)
        {
            case LevelType.Basic:
                reverseRotation = false;
                CreateBasicLevel(randomIndex, targetDirection);
                break;

            case LevelType.Inverted:
                reverseRotation = true;
                CreateBasicLevel(randomIndex, targetDirection);
                break;

            case LevelType.ColorMatch:
                reverseRotation = false;

                CreateFourNestLevel(randomIndex, targetDirection);
                //we want 4 nests, only one being the target color
                break;

            case LevelType.ColorMatchReverse:
                reverseRotation = true;
                CreateFourNestLevel(randomIndex, targetDirection);
                break;

            case LevelType.RandomEagle:
                reverseRotation = false;
                CreateFourNestLevel(randomIndex, targetDirection);
                // 30% chance to spawn an eagle
                if (Random.Range(0f, 1f) < 0.3f)
                {
                    GameObject eagle = Instantiate(eaglePrefab, initialSpawnLocation, Quaternion.identity);
                    eagle.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                }
                break;
        }

        InstantiateObjectPad();

    }

    private void CreateBasicLevel(int index, Direction direction)
    {
        /*
         * Takes in the current selected bird and target, generates it in a random location
         */

        spawnedObject = Instantiate(objectPrefabs[index]);
        spawnedObject.transform.localScale = new Vector3(2f, 2f, 2f);
        spawnedObject.transform.position = initialSpawnLocation;

        var tempTarget = Instantiate(targetPrefabs[index]);
        tempTarget.transform.localScale = nestSize;
        var offset = SetTargetPosition(spawnedObject, direction);
        tempTarget.transform.position = offset;


        GameObject breadcrumbManagerObject = new GameObject("BreadcrumbManager");
        BreadcrumbManager breadcrumbManager = breadcrumbManagerObject.AddComponent<BreadcrumbManager>();
        breadcrumbManager.breadcrumbPrefab = breadcrumbPrefab;
        breadcrumbManager.breadcrumbPrefab.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        breadcrumbManager.objectToTrack = spawnedObject;


        spawnedTargets.Add(tempTarget);

    }

    void CreateFourNestLevel(int index, Direction direction)
    {

        /*
         *  Takes in the current selected bird and target, generates it in a random location and fills the other 3 locations
         */

        spawnedObject = Instantiate(objectPrefabs[index]);
        spawnedObject.transform.localScale = new Vector3(2f, 2f, 2f);
        spawnedObject.transform.position = initialSpawnLocation;

        List<Direction> remainingDirections = new List<Direction>(availableDirections);
        remainingDirections.Remove(direction);


        // Instantiate the correct target in the selected direction
        GameObject correctTarget = Instantiate(targetPrefabs[index]);
        correctTarget.transform.localScale = nestSize;
        var offset = SetTargetPosition(spawnedObject, direction);
        correctTarget.transform.position = offset;
        spawnedTargets.Add(correctTarget);


        for (int i = 0; i < remainingDirections.Count; i++)
        {
            GameObject wrongTarget = Instantiate(fillerTargetPrefab);
            wrongTarget.transform.localScale = nestSize / 2f;
            var wrongTargetOffset = SetTargetPosition(spawnedObject, remainingDirections[i]);
            wrongTarget.transform.position = wrongTargetOffset;
            spawnedTargets.Add(wrongTarget);
        }


        GameObject breadcrumbManagerObject = new GameObject("BreadcrumbManager");
        BreadcrumbManager breadcrumbManager = breadcrumbManagerObject.AddComponent<BreadcrumbManager>();
        breadcrumbManager.breadcrumbPrefab = breadcrumbPrefab;
        breadcrumbManager.breadcrumbPrefab.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        breadcrumbManager.objectToTrack = spawnedObject;

    }

    private void InstantiateObjectPad()
    {
        spawnedPadObject = Instantiate(objectPadPrefab);
        spawnedPadObject.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
        spawnedPadObject.transform.position = initialSpawnLocation - mainCamera.transform.up * 0.1f;
    }

    private Direction GenerateRandomDirection()
    {
        int randomValue = Random.Range(0, 4);

        switch (randomValue)
        {
            case 0:
                return Direction.Right;
            case 1:
                return Direction.Left;
            case 2:
                return Direction.Up;
            case 3:
                return Direction.Down;
            default:
                return Direction.Right;
        }
    }

    private Vector3 SetTargetPosition(GameObject spawnedObject, Direction direction)
    {
        int randomDirection = Random.Range(0, 4);

        Vector3 offset = Vector3.zero;
        float targetDistance = 0.5f;

        switch (direction)
        {
            case Direction.Right:
                offset = mainCamera.transform.right * targetDistance;
                break;
            case Direction.Left:
                offset = -mainCamera.transform.right * targetDistance;
                break;
            case Direction.Up:
                offset = Vector3.up * targetDistance;
                break;
            case Direction.Down:
                offset = Vector3.down * targetDistance;
                break;
        }

        return spawnedObject.transform.position + offset;
    }

    // Level-specific functions here
}

